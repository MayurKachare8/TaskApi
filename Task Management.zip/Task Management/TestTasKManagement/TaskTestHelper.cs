﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestTasKManagement
{
    internal class TaskTestHelper
    {
        public int Id { get; set; }
        public string CreatedDate { get; set; }
        public string TaskName { get; set; }
        public string TaskDescription { get; set; }

        public string TaskStatus { get; set; }
    }
}
